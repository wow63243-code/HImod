#include "main.hpp"

#include "scotland2/shared/modloader.h"

#include "GlobalNamespace/Saber.hpp"
#include "GlobalNamespace/SaberModelController.hpp"
#include "GlobalNamespace/SaberType.hpp"
#include "GlobalNamespace/SaberManager.hpp"

#include "UnityEngine/GameObject.hpp"
#include "UnityEngine/Transform.hpp"
#include "UnityEngine/Vector3.hpp"
#include "UnityEngine/Quaternion.hpp"
#include "UnityEngine/Object.hpp"
#include "UnityEngine/Color.hpp"
#include "UnityEngine/Renderer.hpp"
#include "UnityEngine/Rendering/ShadowCastingMode.hpp"

#include "TMPro/TextMeshPro.hpp"
#include "TMPro/TMP_Text.hpp"
#include "TMPro/TextAlignmentOptions.hpp"
#include "TMPro/FontStyles.hpp"

using namespace GlobalNamespace;
using namespace UnityEngine;
using namespace TMPro;

// ============ TUNE THESE ============
// Local position relative to the blue saber transform (middle of blade-ish)
static constexpr float TEXT_POS_X = 0.0f;
static constexpr float TEXT_POS_Y = 0.0f;
static constexpr float TEXT_POS_Z = 0.35f;

// Local euler rotation — 180 on Y so the text faces the player
static constexpr float TEXT_ROT_X = 0.0f;
static constexpr float TEXT_ROT_Y = 180.0f;
static constexpr float TEXT_ROT_Z = 0.0f;

// Uniform scale — small enough to read without blocking notes
static constexpr float TEXT_SCALE = 0.012f;
// ====================================

static GameObject* heyTextGO = nullptr;

static modloader::ModInfo modInfo{MOD_ID, VERSION, 0};

static void DestroyHeyText() {
    if (heyTextGO) {
        Object::Destroy(heyTextGO);
        heyTextGO = nullptr;
        PaperLogger.info("Destroyed hey text");
    }
}

static void CreateHeyText(Saber* saber) {
    if (!saber) {
        PaperLogger.error("CreateHeyText: saber is null");
        return;
    }

    // Clean any previous instance so nothing leaks between maps
    DestroyHeyText();

    Transform* parent = saber->get_transform();
    if (!parent) {
        PaperLogger.error("CreateHeyText: saber transform is null");
        return;
    }

    heyTextGO = GameObject::New_ctor("HeyModText");
    if (!heyTextGO) {
        PaperLogger.error("CreateHeyText: failed to create GameObject");
        return;
    }

    Transform* t = heyTextGO->get_transform();
    t->SetParent(parent, false);
    t->set_localPosition(Vector3(TEXT_POS_X, TEXT_POS_Y, TEXT_POS_Z));
    t->set_localRotation(Quaternion::Euler(TEXT_ROT_X, TEXT_ROT_Y, TEXT_ROT_Z));
    t->set_localScale(Vector3(TEXT_SCALE, TEXT_SCALE, TEXT_SCALE));

    TextMeshPro* tmp = heyTextGO->AddComponent<TextMeshPro*>();
    if (!tmp) {
        PaperLogger.error("CreateHeyText: AddComponent<TextMeshPro> failed");
        DestroyHeyText();
        return;
    }

    tmp->set_text("hey");
    tmp->set_alignment(TextAlignmentOptions::Center);
    tmp->set_fontStyle(FontStyles::Bold);
    tmp->set_fontSize(36.0f);
    tmp->set_color(Color::get_white());

    // Display-only: kill shadows on our text renderer.
    // No colliders are added anywhere — saber hit detection is untouched.
    auto* renderer = heyTextGO->GetComponent<Renderer*>();
    if (renderer) {
        renderer->set_shadowCastingMode(Rendering::ShadowCastingMode::Off);
        renderer->set_receiveShadows(false);
    }

    PaperLogger.info("Spawned \"hey\" on SaberType %d", static_cast<int>(saber->get_saberType()));
}

// Fires once per saber when its model is initialized.
// Signature verified against bs-cordl 4008 (1.40.8):
//   void Init(Transform* parent, Saber* saber, Color trailTintColor)
MAKE_HOOK_MATCH(
    SaberModelController_Init,
    &SaberModelController::Init,
    void,
    SaberModelController* self,
    Transform* parent,
    Saber* saber,
    Color trailTintColor
) {
    SaberModelController_Init(self, parent, saber, trailTintColor);

    if (!saber) {
        return;
    }

    // SaberB = blue saber. Correct even in left-handed mode.
    if (saber->get_saberType() == SaberType::SaberB) {
        CreateHeyText(saber);
    }
}

// When sabers are torn down (song end / return to menu) Unity destroys
// children, but we still null our pointer so the next map starts clean.
MAKE_HOOK_MATCH(
    SaberManager_Start,
    &SaberManager::Start,
    void,
    SaberManager* self
) {
    // New gameplay session — drop any stale reference
    heyTextGO = nullptr;
    SaberManager_Start(self);
    PaperLogger.info("SaberManager::Start — HeyMod ready for blue saber");
}

MOD_EXTERN_FUNC void setup(CModInfo* info) noexcept {
    *info = modInfo.to_c();
    PaperLogger.info("HeyMod setup complete (target 1.40.8_7379)");
}

MOD_EXTERN_FUNC void late_load() noexcept {
    il2cpp_functions::Init();

    PaperLogger.info("Installing HeyMod hooks...");
    INSTALL_HOOK(PaperLogger, SaberModelController_Init);
    INSTALL_HOOK(PaperLogger, SaberManager_Start);
    PaperLogger.info("HeyMod hooks installed");
}
