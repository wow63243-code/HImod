Param(
    [Parameter(Mandatory=$false)]
    [Switch] $help
)

if ($help -eq $true) {
    Write-Output "`"copy`" - Builds and copies the mod to a connected Quest via adb"
    exit
}

& $PSScriptRoot/build.ps1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$adb = "adb"
& $adb devices
& $adb push "./build/libheymod.so" "/sdcard/Android/data/com.beatgames.beatsaber/files/mods/libheymod.so"
& $adb shell am force-stop com.beatgames.beatsaber
& $adb shell am start -n com.beatgames.beatsaber/com.unity3d.player.UnityPlayerActivity
