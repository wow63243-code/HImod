Param(
    [Parameter(Mandatory=$false)]
    [Switch] $clean,

    [Parameter(Mandatory=$false)]
    [Switch] $help
)

if ($help -eq $true) {
    Write-Output "`"Build`" - Compiles your mod into a `".so`" library"
    Write-Output "`n-- Arguments --`n"
    Write-Output "-Clean `t`t Deletes the `"build`" folder, so that the entire library is rebuilt"
    exit
}

if ($clean.IsPresent) {
    if (Test-Path -Path "build") {
        Remove-Item build -Recurse -Force
    }
}

if (($clean.IsPresent) -or (-not (Test-Path -Path "build"))) {
    New-Item -Path build -ItemType Directory | Out-Null
}

& cmake -G "Ninja" -DCMAKE_BUILD_TYPE="RelWithDebInfo" -B build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& cmake --build ./build
exit $LASTEXITCODE
