Param(
    [Parameter(Mandatory=$false)]
    [String] $qmodName = "",

    [Parameter(Mandatory=$false)]
    [Switch] $help
)

if ($help -eq $true) {
    Write-Output "`"createqmod`" - Creates a .qmod file with your compiled libraries and mod.json."
    Write-Output "`n-- Arguments --`n"
    Write-Output "-QmodName `t The file name of your qmod"
    exit
}

$mod = "./mod.json"
$modTemplate = "./mod.template.json"
$qpmShared = "./qpm.shared.json"

if (Test-Path -Path $modTemplate) {
    $update = -not (Test-Path -Path $mod)

    if (-not $update) {
        $update = (Get-Item $modTemplate).LastWriteTime -gt (Get-Item $mod).LastWriteTime
    }

    if (-not $update -and (Test-Path -Path $qpmShared)) {
        $update = (Get-Item $qpmShared).LastWriteTime -gt (Get-Item $mod).LastWriteTime
    }

    if ($update) {
        & qpm qmod manifest
        if ($LASTEXITCODE -ne 0) {
            exit $LASTEXITCODE
        }
    }
}
elseif (-not (Test-Path -Path $mod)) {
    Write-Output "Error: mod.json and mod.template.json were not present"
    exit 1
}

Write-Output "Creating qmod from mod.json"

$modJson = Get-Content $mod -Raw | ConvertFrom-Json

if ($qmodName -eq "") {
    $qmodName = $modJson.name
}

$filelist = @($mod)

$cover = "./" + $modJson.coverImage
if ((-not ($cover -eq "./")) -and (Test-Path $cover)) {
    $filelist += , $cover
}

foreach ($modFile in $modJson.modFiles) {
    $path = "./build/" + $modFile
    if (-not (Test-Path $path)) {
        $path = "./extern/libs/" + $modFile
    }
    if (-not (Test-Path $path)) {
        Write-Output "Error: could not find mod file $modFile"
        exit 1
    }
    $filelist += , $path
}

if ($modJson.libraryFiles) {
    foreach ($lib in $modJson.libraryFiles) {
        $path = "./extern/libs/" + $lib
        if (-not (Test-Path $path)) {
            $path = "./build/" + $lib
        }
        if (-not (Test-Path $path)) {
            Write-Output "Error: could not find library file $lib"
            exit 1
        }
        $filelist += , $path
    }
}

$archive = "./$qmodName.qmod"
if (Test-Path $archive) {
    Remove-Item $archive -Force
}

Compress-Archive -Path $filelist -DestinationPath $archive -Force
# PowerShell Compress-Archive makes .zip; rename to .qmod
if (Test-Path ($archive + ".zip")) {
    Move-Item ($archive + ".zip") $archive -Force
}

Write-Output "Created $archive"
exit 0
