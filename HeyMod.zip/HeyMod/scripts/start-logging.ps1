Param(
    [Parameter(Mandatory=$false)]
    [Switch] $help
)

if ($help -eq $true) {
    Write-Output "`"start-logging`" - Streams Beat Saber logcat filtered for HeyMod"
    exit
}

adb logcat -c
adb logcat | Select-String -Pattern "HeyMod|heymod|scotland2|modloader"
