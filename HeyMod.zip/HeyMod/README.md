# Hey Mod

Floats the text **"hey"** on the middle of the **blue saber** (`SaberType.SaberB`) in Beat Saber on Meta Quest.

- Display-only, client-side
- Does **not** touch scoring, notes, multiplayer, or saber collision
- Works on every map and difficulty
- Correct in left-handed mode (uses saber type, not left/right)

## Target

- **Game:** Beat Saber `1.40.8_7379` (latest MBF-moddable Quest version)
- **Codegen:** bs-cordl `4008.*`
- **Platform:** Meta Quest standalone (arm64), scotland2 loader

## Build (GitHub Actions — no PC needed)

1. Push this repo to GitHub
2. Go to **Actions** → **Build HeyMod** → **Run workflow**
3. Download the `HeyMod.qmod` artifact
4. Install with [ModsBeforeFriday](https://mbf.bsquest.xyz)

## Tune position / scale

Edit the constants at the top of `src/main.cpp`:

```cpp
TEXT_POS_X / Y / Z   // local position on the saber
TEXT_ROT_X / Y / Z   // local euler rotation
TEXT_SCALE           // uniform scale
```

## Logs

Filter logcat for `HeyMod`. You should see:

- `HeyMod setup complete`
- `HeyMod hooks installed`
- `Spawned "hey" on SaberType 1` when a song starts

## Honesty

Class/member names were checked against the public **bs-cordl 4008** headers for `1.40.8`.  
This project was **not** run on a headset. Build it, install it, and verify in-game.
