#pragma once

#include "beatsaber-hook/shared/utils/logging.hpp"
#include "beatsaber-hook/shared/utils/il2cpp-functions.hpp"
#include "beatsaber-hook/shared/utils/hooking.hpp"
#include "paper2_scotland2/shared/logger.hpp"

static constexpr auto PaperLogger = Paper::ConstLoggerContext("HeyMod");
